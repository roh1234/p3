#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "pzip.h"

/**
 * pzip() - zip an array of characters in parallel
 *
 * Inputs:
 * @n_threaAds:		   The number of threads to use in pzip
 * @input_chars:		   The input characters (a-z) to be zipped
 * @input_chars_size:	   The number of characaters in the input file
 *
 * Outputs:
 * @zipped_chars:       The array of zipped_char structs
 * @zipped_chars_count:   The total count of inserted elements into the zippedChars array.
 * @char_frequency[26]: Total number of occurences
 *
 * NOTE: All outputs are already allocated. DO NOT MALLOC or REASSIGN THEM !!!
 *
 */
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_barrier_t barrier;
int sizeofINDEX;
struct arguments {
	int i;
	int start;
	int division;
	int n_threads;
	char *input_chars;
	int *char_frequency;
	struct zipped_char *zipped_chars;
	int *indexesForGlobal;
};


//struct data pthread
void *update(void *arg)
{
	struct arguments * myarg = (struct arguments *) arg;
	struct zipped_char *localResult = malloc(sizeof(struct zipped_char) * myarg->division);
	int counter = 0;
	char past = '\0';
	int whereInArray = 0;
	//print what thread it should be in 
	
	// for the start is the division calc before, and less than the start + division
	for (int t = myarg->start; t < (myarg->start + myarg->division); t++) {
		//initiial
		if (counter == 0 || past == '\0') {
			counter++;
			past = myarg->input_chars[t];
			pthread_mutex_lock(&lock);
			myarg->char_frequency[past-97] = myarg->char_frequency[past-97] + 1;
			pthread_mutex_unlock(&lock);
			
		}
		// seeing if this is the same
		else if (past == myarg->input_chars[t]) {
			counter++;
			pthread_mutex_lock(&lock);
			myarg->char_frequency[past-97] = myarg->char_frequency[past-97] + 1;
			pthread_mutex_unlock(&lock);
		}
		else if (past != myarg->input_chars[t]){
			struct zipped_char *local_zipped_chars =  malloc(sizeof(struct zipped_char));
			local_zipped_chars->character = past;
			local_zipped_chars->occurence = counter;

			pthread_mutex_lock(&lock);
			myarg->char_frequency[myarg->input_chars[t]-97] += 1;
			pthread_mutex_unlock(&lock);
			counter = 1;
			past = myarg->input_chars[t];
			localResult[whereInArray] = *local_zipped_chars;
			whereInArray++;
			(myarg)->indexesForGlobal[myarg->i]+= 1;
		}
		if (t == myarg->start + myarg->division - 1){
			struct zipped_char *local_zipped_chars = malloc(sizeof(struct zipped_char));
			local_zipped_chars->character = past;
			local_zipped_chars->occurence = counter;
			
			pthread_mutex_lock(&lock);
			//myarg->char_frequency[past-97] = myarg->char_frequency[past-97] + 1;
			pthread_mutex_unlock(&lock);
			localResult[whereInArray] = *local_zipped_chars;
			whereInArray++;
			(myarg)->indexesForGlobal[myarg->i]+=1;
		}
		
	}
		
	pthread_barrier_wait(&barrier);

	//return local result 
	return localResult;
}


void pzip(int n_threads, char *input_chars, int input_chars_size,
	  struct zipped_char *zipped_chars, int *zipped_chars_count,
	  int *char_frequency)
{
	int * indexesForGlobal= malloc(input_chars_size);

	pthread_t threads[n_threads];
//	pthread_attr_t attr;
	pthread_barrier_init(&barrier, NULL, n_threads);

	struct zipped_char *localResults[n_threads];

	//size of input char each thread will takeWS
	int division = input_chars_size / n_threads;

	struct arguments threadArguments [n_threads];// ={i,temp,division,input_chars,char_frequency,zipped_chars,n_threads,indexesForGlobal};
	//loop to create the threads 
	for (int i = 0; i < n_threads; i++) {
		//the bounds for each thread
		int temp = division * i;
		//allocate memory
		//return local result
		// alloc on heap
		threadArguments[i].i = i;
		threadArguments[i].start = temp;
		threadArguments[i].division = division;
		threadArguments[i].input_chars = input_chars;
		threadArguments[i].char_frequency = char_frequency;
		threadArguments[i].zipped_chars = zipped_chars;
		threadArguments[i].n_threads = n_threads;
		threadArguments[i].indexesForGlobal = indexesForGlobal;

		pthread_create(&threads[i], NULL, update, (void *) &threadArguments[i]);
		// struct zipped_char *localResult;
    	// pthread_join(threads[i],(void *) &localResult);
		// localResults[i] = localResult;	
	}
	


	for (int p = 0; p < n_threads; p++) {
	//var to hold return value of 
	struct zipped_char *localResult;
    pthread_join(threads[p],(void *) &localResult);
	localResults[p] = localResult;	
  }
  //mem copy 
  //counting all of the local result sizes 

	for (int i = 0; i < n_threads; i++){
		*zipped_chars_count += indexesForGlobal[i];
	}
	

	int offset = 0;

  //local result is an array of results and each zipped char array is pointing to another local result array 
  //indexesForGlobal = that many indexes for that thread;
	for (int i = 0; i < n_threads; i++){
		if (i != 0){
		offset = indexesForGlobal[i-1];
		}
		memcpy(&zipped_chars[offset], localResults[i], sizeof(struct zipped_char)* indexesForGlobal[i]);	
	}

	pthread_barrier_destroy(&barrier);
	return;
}
